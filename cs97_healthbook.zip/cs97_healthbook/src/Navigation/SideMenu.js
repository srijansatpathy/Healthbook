import React from 'react';

// Import Icons
import * as BootsIcons from "react-icons/bs";
import * as RemixIcons from "react-icons/ri";
import * as GrommIcons from "react-icons/gr";
import * as IcomoIcons from "react-icons/im";


// A list of side menu info
export const SideMenuInfo = [

    // Side tab #1
    {
        title: 'Profile',
        path:   '/profile',
        icon: <IcomoIcons.ImProfile />,
        classFormat: 'menuText'
    },

    // Side tab #2 
    {
        title: 'Dashboard',
        path:   '/dashboard',
        icon: <RemixIcons.RiDashboardLine />,
        classFormat: 'menuText'
    },

    // Side tab #3
    {
        title: 'Posts',
        path:   '/posts',
        icon: <BootsIcons.BsFilePost />,
        classFormat: 'menuText'
    },

    // Side tab #4
    {
        title: 'Group',
        path:   '/group',
        icon: <GrommIcons.GrGroup />,
        classFormat: 'menuText'
    },

    // Side tab #5
    {
        title: 'Message',
        path:   '/message',
        icon: <RemixIcons.RiMessage2Fill />,
        classFormat: 'menuText'
    }

] 
