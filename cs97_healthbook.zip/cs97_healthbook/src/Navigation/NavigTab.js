import React, {useState} from 'react';
import { Link } from 'react-router-dom';
import './NavigTab.css';
import { SideMenuInfo } from './SideMenu.js';
import { IconContext } from 'react-icons';

// Import Icons and Images
import logo_hea from '../Images/single_logo.png';
import logo_main from '../Images/final_logo.png';
import * as HeroIcons from "react-icons/hi";
import * as RemixIcons from "react-icons/ri";
import * as FontaweIcons from "react-icons/fa";
import * as BoxIcons from "react-icons/bi";


function NavigationTab() {

    // create side bar variables
    const [sidebar, setSidebar] = useState(false);

    // sidebar switch
    const showSidebar = () => setSidebar(!sidebar);
    return (
        <>

        {/* Modify all the icon values below here */}
        <IconContext.Provider value ={{size: '18'}}>
        
        <div className="menuTab">

            
        <Link to ='#' className="menuOptions" activeStyle={{color: "#FFFFFF"}} >                   
            <HeroIcons.HiViewList size="42px" onClick={showSidebar}/>                     
        </Link>

        {/* <img src={logo_main} className="logoMain"  
                            width = '220' height= '62'   /> */}
            <div className="testingTab">
            <Link to='/dashboard' className="menuTitile" marign-left>
                Dashboard
            </Link>
            </div>

        </div>  
        
        {/* see the sidebar mode is on or not */}
        <nav className={sidebar ? "mainMenu active": "mainMenu"}>

           
            {/* Create an unordered list of menu options items */}
            <ul className="menuItems" onClick={showSidebar}>
                <li className='menuToogle'>
                    <Link to='#' className="menuOptions">
                        <RemixIcons.RiArrowLeftCircleFill size="42px" />
                    </Link>
                </li>
                <li>
                    <img src={logo_hea} className="logoImg"  
                                        width = '122' height= '122'   />
                </li>
                {/* Create links to main menus options in the list*/}
                {SideMenuInfo.map((item, index) => {
                        return (
                            <li key={index} className={item.classFormat}>
                                <Link to={item.path}>
                                    {item.icon}
                                    <span>{item.title}</span>
                                </Link>
                            </li>
                        )
                    })}
            </ul>
                    
            
        </nav>
        </IconContext.Provider>
        </>
    );
}

export default NavigationTab;