import React from 'react';
import '../index.css'

function Dashboard() {
    return (
        <div className='dashboard' className='container'>
            <h1>Dashboard</h1>
        </div>
    );
}


export default Dashboard;